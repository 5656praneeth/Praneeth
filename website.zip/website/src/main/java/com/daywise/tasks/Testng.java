package com.daywise.tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Testng {
	static WebDriver driver;
	
	@BeforeTest
	public void StartDriver() {
		driver = WebDriverSetup.getWebDriver();
	}
	
	@Test(priority = 1)
	
	public void LaunchURL() throws InterruptedException {
	     driver.manage().window().maximize();
		 driver.get("https://seleniumbase.io/demo_page/");
	        Thread.sleep(2000);
	}
	@Test(priority = 2)
	public void SwitchingFrameGetText() {
		 
	        WebElement userid=driver.findElement(By.xpath("//input[@id='myTextInput']"));
	        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@name='frameName2']")));
	        WebElement text=driver.findElement(By.xpath("//h4[contains(text(),'iFrame Text')]"));
	        System.out.println(text.getText());
		
	}
	@AfterTest
	public void QuitBrowser() {
		driver.quit();
	}
	

}
