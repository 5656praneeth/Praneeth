package com.daywise.tasks;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        // Set path to Edge WebDriver
        System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");

        // Initialize WebDriver
        WebDriver driver = new EdgeDriver();
        driver.manage().window().maximize();

        // Navigate to the demo page
/*     driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        Thread.sleep(2000);
         WebElement userId=driver.findElement(By.xpath("//input[@name='username']"));
         userId.sendKeys("Admin");
         
         WebElement Password=driver.findElement(By.xpath("//input[@name='password']"));
         Password.sendKeys("admin123");
          
         WebElement Login=driver.findElement(By.xpath("//button[@type='submit']"));
         Login.click();
         
         Thread.sleep(2000);
         // mouse hover
         Actions action=new Actions(driver);
         action.moveToElement(driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span")))
     .click().perform();
 
     // double click
        driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
        Thread.sleep(2000);
        Actions action=new Actions(driver);
        action.contextClick(driver.findElement(By.xpath("//span[contains(text(),'right click me')]"))).perform();
        		Thread.sleep(4000);
        driver.findElement(By.xpath("//li[.='Edit']")).click();
        Alert alert=driver.switchTo().alert();
        alert.accept();
       
  
        
      //drag and drop 
        driver.get("https://artoftesting.com/samplesiteforselenium");
        Thread.sleep(2000);
        Actions action=new Actions(driver);
        Thread.sleep(2000);
        WebElement source=driver.findElement(By.xpath("//img[@id='myImage']"));
        WebElement destination=driver.findElement(By.xpath("//div[@id='targetDiv']"));
        action.dragAndDrop(source,destination).build().perform();
 
        
    
        //dropdown 
        driver.get("https://artoftesting.com/samplesiteforselenium");
        Thread.sleep(2000);
        WebElement dropdown=driver.findElement(By.xpath("//select[@id='testingDropdown']"));
        Select select=new Select(dropdown);
        Thread.sleep(2000);
        select.selectByIndex(1);
        Thread.sleep(2000);
        select.selectByValue("Automation Testing");
        Thread.sleep(2000);
      select.deselectByVisibleText("Manual Testing");
     */
        
     
        //windows handling
        driver.get("https://seleniumbase.io/demo_page/");
        Thread.sleep(2000);
        String parentWindow=driver.getWindowHandle();
        driver.findElement(By.xpath("//a[@id='myLink1']")).click();
        Set<String>Windowhandles=driver.getWindowHandles();
        for(String windowhandle:Windowhandles) {
        	driver.switchTo().window(windowhandle);
        	
        }
        
       
   /*
        //iframe
        
        
        driver.get("https://seleniumbase.io/demo_page/");
        Thread.sleep(2000);
        WebElement userid=driver.findElement(By.xpath("//input[@id='myTextInput']"));
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@name='frameName2']")));
        WebElement text=driver.findElement(By.xpath("//h4[contains(text(),'iFrame Text')]"));
        System.out.println(text.getText());
        
        */
        
   
        
        
        
        
        
    
    
    }
}
