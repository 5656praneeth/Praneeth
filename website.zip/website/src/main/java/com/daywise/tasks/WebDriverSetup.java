package com.daywise.tasks;

import java.util.Scanner;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class WebDriverSetup {

	public static WebDriver getWebDriver() {
		Scanner sc = new Scanner(System.in);
		WebDriver driver = null;

		System.out.println("Please enter the browser name (chrome/Edge):");
		String browser = sc.nextLine().toLowerCase();
        //invoke a browser
		switch (browser) {
		case "edge":
			// Set the system property for the Microsoft Edge driver executable
			System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");
			driver = new EdgeDriver();
			System.out.println("Edge Browser Opened Successfully");
			break;

		case "chrome":
			// Set the system property for the Chrome driver executable
			System.setProperty("webdriver.chrome.driver","C:\\Users\\2282427\\ee\\project\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			System.out.println("Chrome Browser Opened Successfully");
			break;

		default: 
			System.out.print("Enter valid Browser");
			break;

		}
		sc.close();
		return driver;
	}
	

}
