package com.daywise.tasks;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import java.io.FileOutputStream;
import java.io.IOException;

public class Excel {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		 Workbook workbook = new XSSFWorkbook();
		        Sheet sheet = workbook.createSheet("TestData");

		        // Create a row and a cell, then write data
		        Row row = sheet.createRow(0); // Row 0
		        Cell cell = row.createCell(0); // Column A
		        cell.setCellValue("Hello Excel!");

            String cellValue = cell.getStringCellValue();

            System.out.println("Value read from Excel: " + cellValue);


		        try {
		            FileOutputStream fos = new FileOutputStream("TestData.xlsx");
		            workbook.write(fos);
		            fos.close();
		            workbook.close();
		            System.out.println("Data written to Excel successfully.");
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		        
		        System.setProperty("webdriver.edge.driver", "drivers/msedgedriver.exe");

		        // Initialize WebDriver
		        WebDriver driver = new EdgeDriver();
		        driver.manage().window().maximize();
		        driver.get("https://seleniumbase.io/demo_page/");
		        Thread.sleep(2000);
		        WebElement userid=driver.findElement(By.xpath("//input[@id='myTextInput']"));
		        userid.sendKeys(cellValue);


	}

}
